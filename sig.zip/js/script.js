$(document).ready(function() {
  $('#table_data, .table-admin').dataTable();
});